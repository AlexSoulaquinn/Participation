﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PokeApi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            string path = "https://pokeapi.co/api/v2/pokemon?offset=0&limit=964";

            PokemonApi pokemonInfo;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(path);
                string json = client.GetStringAsync(path).Result;

                pokemonInfo = JsonConvert.DeserializeObject<PokemonApi>(json);

                foreach (var pokemon in pokemonInfo.results)
                {
                    lstPokemon.Items.Add(pokemon);
                }

            }
        }

        private void btnChoosePokemon_Click(object sender, RoutedEventArgs e)
        {
            var selectedPokemonFromList = (resultObject)lstPokemon.SelectedItem;

            string path = $"{selectedPokemonFromList.url}";

            pokemonObject pokemon;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(path);
                string json = client.GetStringAsync(path).Result;

                pokemon = JsonConvert.DeserializeObject<pokemonObject>(json);

                lstPokemonInfo.Items.Add(pokemon);
                string imgPath =$"https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/ {pokemon.id}";

                imgSprite.Source = new BitmapImage(new Uri(imgPath));
            }
        }
    }
}
